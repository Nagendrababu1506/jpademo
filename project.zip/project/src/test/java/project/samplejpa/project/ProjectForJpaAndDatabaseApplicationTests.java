package project.samplejpa.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectForJpaAndDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
